package HotelManagementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddDriver extends JFrame implements ActionListener {

    JTextField nameText, ageText, cCompanyText, cNameText, locText;
    JComboBox genderComboBox, availComboBox;
    JButton add, back;
    AddDriver(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,875,490);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        JLabel label = new JLabel("Add New Driver");
        label.setBounds(174,10,200,22);
        label.setFont(new Font("serif", Font.BOLD, 22));
        label.setForeground(new Color(13, 81, 140));
        pan.add(label);

        JLabel name = new JLabel("Name");
        name.setBounds(64,70,102,22);
        name.setFont(new Font("serif", Font.BOLD,14));
        name.setForeground(Color.BLACK);
        pan.add(name);

        nameText = new JTextField();
        nameText.setBounds(174,70,156,20);
        nameText.setFont(new Font("serif",Font.BOLD,14));
        nameText.setForeground(Color.WHITE);
        nameText.setBackground(new Color(13, 81, 140));
        pan.add(nameText);

        JLabel age = new JLabel("Age");
        age.setBounds(64,110,102,22);
        age.setFont(new Font("serif", Font.BOLD,14));
        age.setForeground(Color.BLACK);
        pan.add(age);

        ageText = new JTextField();
        ageText.setBounds(174,110,156,20);
        ageText.setFont(new Font("Tahoma",Font.BOLD,14));
        ageText.setForeground(Color.WHITE);
        ageText.setBackground(new Color(13, 81, 140));
        pan.add(ageText);

        JLabel gender = new JLabel("Gender");
        gender.setBounds(64,150,102,22);
        gender.setFont(new Font("serif", Font.BOLD,14));
        gender.setForeground(Color.BLACK);
        pan.add(gender);

        genderComboBox = new JComboBox(new String[]{"Male","Female"});
        genderComboBox.setBounds(176,150,154,20);
        genderComboBox.setFont(new Font("serif", Font.BOLD,14));
        genderComboBox.setForeground(Color.WHITE);
        genderComboBox.setBackground(new Color(13, 81, 140));
        pan.add(genderComboBox);

        JLabel cCompany = new JLabel("Car Company");
        cCompany.setBounds(64,190,110,22);
        cCompany.setFont(new Font("serif", Font.BOLD,14));
        cCompany.setForeground(Color.BLACK);
        pan.add(cCompany);

        cCompanyText = new JTextField();
        cCompanyText.setBounds(174,190,156,20);
        cCompanyText.setFont(new Font("serif",Font.BOLD,14));
        cCompanyText.setForeground(Color.WHITE);
        cCompanyText.setBackground(new Color(13, 81, 140));
        pan.add(cCompanyText);

        JLabel carN = new JLabel("Car Name");
        carN.setBounds(64,230,102,22);
        carN.setFont(new Font("serif", Font.BOLD,14));
        carN.setForeground(Color.BLACK);
        pan.add(carN);

        cNameText = new JTextField();
        cNameText.setBounds(174,230,156,20);
        cNameText.setFont(new Font("serif", Font.BOLD,14));
        cNameText.setForeground(Color.WHITE);
        cNameText.setBackground(new Color(13, 81, 140));
        pan.add(cNameText);

        JLabel available = new JLabel("Available");
        available.setBounds(64,270,102,22);
        available.setFont(new Font("serif", Font.BOLD,14));
        available.setForeground(Color.BLACK);
        pan.add(available);

        availComboBox = new JComboBox(new String[]{"Yes", "No"});
        availComboBox.setBounds(176,270,154,20);
        availComboBox.setFont(new Font("serif",Font.BOLD,14));
        availComboBox.setForeground(Color.WHITE);
        availComboBox.setBackground(new Color(13, 81, 140));
        pan.add(availComboBox);

        JLabel loc = new JLabel("Location");
        loc.setBounds(64,310,102,22);
        loc.setFont(new Font("serif", Font.BOLD,14));
        loc.setForeground(Color.BLACK);
        pan.add(loc);

        locText = new JTextField();
        locText.setBounds(174,310,156,20);
        locText.setFont(new Font("serif",Font.BOLD,14));
        locText.setForeground(Color.WHITE);
        locText.setBackground(new Color(13, 81, 140));
        pan.add(locText);

        add = new JButton("ADD");
        add.setBounds(80,380,111,33);
        add.setForeground(Color.BLACK);
        add.setBackground(new Color(191, 135, 115));
        add.addActionListener(this);
        pan.add(add);

        back = new JButton("BACK");
        back.setBounds(200,380,111,33);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/driver.png"));
        Image i = img.getImage().getScaledInstance(300,300, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(500,60,300,300);
        pan.add(lab);

        setUndecorated(true);
        setLayout(null);
        setBounds(30,120,885, 500);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == add){
            String d_name = nameText.getText();
            String age = ageText.getText();
            String gender = (String) genderComboBox.getSelectedItem();
            String c_company = cCompanyText.getText();
            String c_name = cNameText.getText();
            String available =(String)  availComboBox.getSelectedItem();
            String location = locText.getText();

            try{
                con c = new con();
                String q = "insert into driver values('"+ d_name +"','"+age+"', '"+gender+"', '"+ c_company +"', '"+ c_name +"','"+available+"', '"+location+"')";
                c.statement.executeUpdate(q);
                JOptionPane.showMessageDialog(null, "Driver Added");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();
            }

        }
        else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new AddDriver();
    }
}
