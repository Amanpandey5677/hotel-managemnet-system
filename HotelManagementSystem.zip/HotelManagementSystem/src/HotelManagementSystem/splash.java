package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class splash extends JFrame implements ActionListener {

    splash(){

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/first.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, 0, 1024, 683 );  // locationx, locationy, length, breadth
        add(image);

        JLabel text = new JLabel("Hotel Management System");
        text.setBounds(250, 30, 1000, 90);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("serif", Font.PLAIN, 50));  // it takes 3 values Font Family, Font Type, Size
        image.add(text);

        JButton next = new JButton("Next");
        next.setBounds(850, 560, 150, 50);
        next.setBackground(new Color(44, 69, 10));
        next.setForeground(Color.WHITE);
        next.setFont(new Font("serif", Font.PLAIN, 30));
        next.addActionListener(this);
        image.add(next);

        setLayout(null);  // to use our own layout instead of border layout or grid layout
//        setLocation(100, 100);
//        setSize(1024, 683);
        setBounds(100, 100, 1024, 683);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae){
       setVisible(false);
       new Login();
    }


    public static void main(String[] args) {
        new splash();  // Creating object of class to run it
    }
}
