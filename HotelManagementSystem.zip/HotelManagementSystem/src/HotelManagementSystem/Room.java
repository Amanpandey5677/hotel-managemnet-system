package HotelManagementSystem;
import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Room extends JFrame implements ActionListener {

    JTable roomTable;
    JButton back;
    Room(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/roomImage.png"));
        Image i = img.getImage().getScaledInstance(305,204, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(590,326,305,204);
        pan.add(lab);

        roomTable = new JTable();
        roomTable.setBounds(10, 40, 500, 400);
        roomTable.setBackground(new Color(242, 242, 242));
        pan.add(roomTable);

        try{
            con c = new con();
            String q = "select * from room";
            ResultSet rs = c.statement.executeQuery(q);
            roomTable.setModel(DbUtils.resultSetToTableModel(rs));

        }catch (Exception e){
            e.printStackTrace();
        }

        back = new JButton("BACK");
        back.setBounds(200,500,120,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        JLabel room = new JLabel("Room No.");
        room.setBounds(12,15,80,19);
        room.setForeground(new Color(13, 81, 140));
        room.setFont(new Font("Tahoma", Font.BOLD, 14));
        pan.add(room);


        JLabel availability = new JLabel("Availability");
        availability.setBounds(119,15,80,19);
        availability.setForeground(new Color(13, 81, 140));
        availability.setFont(new Font("Tahoma", Font.BOLD, 14));
        pan.add(availability);

        JLabel Clean = new JLabel("Clean Status");
        Clean.setBounds(216,15,150,19);
        Clean.setForeground(new Color(13, 81, 140));
        Clean.setFont(new Font("Tahoma", Font.BOLD, 14));
        pan.add(Clean);


        JLabel Price = new JLabel("Price");
        Price.setBounds(330,15,80,19);
        Price.setForeground(new Color(13, 81, 140));
        Price.setFont(new Font("Tahoma", Font.BOLD, 14));
        pan.add(Price);

        JLabel Bed = new JLabel("Bed Type");
        Bed.setBounds(417,15,80,19);
        Bed.setForeground(new Color(13, 81, 140));
        Bed.setFont(new Font("Tahoma", Font.BOLD, 14));
        pan.add(Bed);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()== back){
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Room();
    }

}
