package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class UpdateRoomStatus extends JFrame implements ActionListener {
    Choice ch;
    JTextField textField3, textField4;
    JButton check, update, back;
    UpdateRoomStatus(){
        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/roomUpdate.png"));
        Image i = img.getImage().getScaledInstance(300,300,Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel label = new JLabel(imgg);
        label.setBounds(500,100,300,300);
        pan.add(label);

        JLabel label1  = new JLabel("Update Room Status");
        label1.setBounds(130,30,400,40);
        label1.setFont(new Font("serif", Font.BOLD, 35));
        label1.setForeground(new Color(13, 81,140));
        pan.add(label1);

        JLabel label2  = new JLabel("Room Number: ");
        label2.setBounds(25,150,150,25);
        label2.setFont(new Font("serif", Font.BOLD, 20));
        label2.setForeground(new Color(13,81, 140));
        pan.add(label2);

        ch = new Choice();
        ch.setBounds(250,150,140,25);
        ch.setForeground(Color.WHITE);
        ch.setBackground(new Color(191, 135, 115));
        pan.add(ch);

        try {
            con c = new con();
            ResultSet rs = c.statement.executeQuery("select * from room");
            while (rs.next()){
                ch.add(rs.getString("room_number"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        JLabel label3  = new JLabel("Availability :");
        label3.setBounds(25,230,150,25);
        label3.setFont(new Font("serif", Font.BOLD, 20));
        label3.setForeground(new Color(13,81, 140));
        pan.add(label3);

        textField3 = new JTextField();
        textField3.setBounds(250,230,140,20);
        textField3.setForeground(Color.WHITE);
        textField3.setBackground(new Color(191, 135, 115));
        pan.add(textField3);

        JLabel label4  = new JLabel("Cleaning Status :");
        label4.setBounds(25,310,150,25);
        label4.setFont(new Font("serif", Font.BOLD, 20));
        label4.setForeground(new Color(13,81, 140));
        pan.add(label4);

        textField4 = new JTextField();
        textField4.setBounds(250,310,140,20);
        textField4.setForeground(Color.WHITE);
        textField4.setBackground(new Color(191, 135, 115));
        pan.add(textField4);

        check = new JButton("Check");
        check.setBounds(40,430,100,30);
        check.setForeground(Color.BLACK);
        check.setBackground(new Color(191, 135, 115));
        check.addActionListener(this);
        pan.add(check);

        update = new JButton("Update");
        update.setBounds(190,430,100,30);
        update.setForeground(Color.BLACK);
        update.setBackground(new Color(191, 135, 115));
        update.addActionListener(this);
        pan.add(update);

        back = new JButton("Back");
        back.setBounds(340,430,100,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);



        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == check){
            String num = ch.getSelectedItem();
            String q = "select * from room where room_number ='"+ num +"'";

            try{
                con c = new con();
                ResultSet rs = c.statement.executeQuery(q);

                while (rs.next()){
                    textField3.setText(rs.getString("availaibility"));
                    textField4.setText(rs.getString("cleaning_status"));
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else if (e.getSource() == update) {
            try {
                con C  = new con();
                String r_num = ch.getSelectedItem();
                String avl = textField3.getText();
                String cs = textField4.getText();

                C.statement.executeUpdate("update room  set availaibility = '"+ avl +"', cleaning_status = '"+ cs +"' where room_number = '"+ r_num +"'");
                JOptionPane.showMessageDialog(null, "Updated Successfully");
                setVisible(false);

            }
            catch (Exception E){
                E.printStackTrace();
            }
        }
        else {
            setVisible(false);
        }

    }
    public static void main(String[] args) {
        new UpdateRoomStatus();
    }
}
