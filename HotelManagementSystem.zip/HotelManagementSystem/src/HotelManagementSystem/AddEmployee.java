package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddEmployee extends JFrame implements ActionListener {
    JTextField nameText, ageText, salaryText, phoneText, aadharText, emailText;
    JComboBox genderComboBox, jobComboBox;
    JButton add, back;
    AddEmployee(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,875,490);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        JLabel AED = new JLabel("Add Employee Details");
        AED.setBounds(520,24,445,35);
        AED.setFont(new Font("serif", Font.BOLD, 25));
        AED.setForeground(new Color(13, 81, 140));
        pan.add(AED);

        JLabel name = new JLabel("Name");
        name.setBounds(60,30,150,27);
        name.setFont(new Font("serif", Font.BOLD, 17));
        name.setForeground(Color.BLACK);
        pan.add(name);

        nameText = new JTextField();
        nameText.setBounds(200,30,150,27);
        nameText.setFont(new Font("serif", Font.BOLD,14));
        nameText.setForeground(Color.WHITE);
        nameText.setBackground(new Color(13, 81, 140));
        pan.add(nameText);

        JLabel Age = new JLabel("AGE");
        Age.setBounds(60,80,150,27);
        Age.setFont(new Font("serif", Font.BOLD, 17));
        Age.setForeground(Color.BLACK);
        pan.add(Age);

        ageText = new JTextField();
        ageText.setBounds(200,80,150,27);
        ageText.setFont(new Font("serif", Font.BOLD,14));
        ageText.setForeground(Color.WHITE);
        ageText.setBackground(new Color(13, 81, 140));
        pan.add(ageText);

        JLabel gender = new JLabel("Gender");
        gender.setBounds(60,130,150,27);
        gender.setFont(new Font("serif", Font.BOLD, 17));
        gender.setForeground(Color.BLACK);
        pan.add(gender);

        genderComboBox = new JComboBox(new String[]{"Male","Female"});
        genderComboBox.setBounds(200,130,150,27);
        genderComboBox.setFont(new Font("serif", Font.BOLD,14));
        genderComboBox.setForeground(Color.WHITE);
        genderComboBox.setBackground(new Color(13, 81, 140));
        pan.add(genderComboBox);

        JLabel job = new JLabel("Job");
        job.setBounds(60,180,150,27);
        job.setFont(new Font("serif", Font.BOLD,17));
        job.setForeground(Color.BLACK);
        pan.add(job);

        jobComboBox = new JComboBox(new String[]{"Front Desk", "Housekeeping", "Kitchen Staff","Room Service", "Manager", "Accountant","Chef"});
        jobComboBox.setBounds(200,180,150,27);
        jobComboBox.setFont(new Font("serif", Font.BOLD,14));
        jobComboBox.setForeground(Color.WHITE);
        jobComboBox.setBackground(new Color(13, 81, 140));
        pan.add(jobComboBox);

        JLabel salary = new JLabel("Salary");
        salary.setBounds(60,230,150,27);
        salary.setFont(new Font("serif", Font.BOLD, 17));
        salary.setForeground(Color.BLACK);
        pan.add(salary);

        salaryText = new JTextField();
        salaryText.setBounds(200,230,150,27);
        salaryText.setFont(new Font("serif", Font.BOLD,14));
        salaryText.setForeground(Color.WHITE);
        salaryText.setBackground(new Color(13, 81, 140));
        pan.add(salaryText);

        JLabel phone = new JLabel("Phone");
        phone.setBounds(60,280,150,27);
        phone.setFont(new Font("serif", Font.BOLD, 17));
        phone.setForeground(Color.BLACK);
        pan.add(phone);

        phoneText = new JTextField();
        phoneText.setFont(new Font("serif", Font.BOLD,14));
        phoneText.setBounds(200,280,150,27);
        phoneText.setForeground(Color.WHITE);
        phoneText.setBackground(new Color(13, 81, 140));
        pan.add(phoneText);

        JLabel aadhar = new JLabel("Aadhar");
        aadhar.setBounds(60,330,150,27);
        aadhar.setFont(new Font("serif", Font.BOLD, 17));
        aadhar.setForeground(Color.BLACK);
        pan.add(aadhar);

        aadharText = new JTextField();
        aadharText.setBounds(200,330,150,27);
        aadharText.setFont(new Font("serif", Font.BOLD,14));
        aadharText.setForeground(Color.WHITE);
        aadharText.setBackground(new Color(13, 81, 140));
        pan.add(aadharText);

        JLabel email = new JLabel("Email");
        email.setBounds(60,380,150,27);
        email.setFont(new Font("serif", Font.BOLD, 17));
        email.setForeground(Color.BLACK);
        pan.add(email);

        emailText = new JTextField();
        emailText.setBounds(200,380,150,27);
        emailText.setFont(new Font("serif", Font.BOLD,14));
        emailText.setForeground(Color.WHITE);
        emailText.setBackground(new Color(13, 81, 140));
        pan.add(emailText);

        add = new JButton("ADD");
        add.setBounds(80,430,100,30);
        add.setForeground(Color.BLACK);
        add.setBackground(new Color(191, 135, 115));
        add.addActionListener(this);
        pan.add(add);

        back = new JButton("BACK");
        back.setBounds(200,430,100,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/employee.png"));
        Image i = img.getImage().getScaledInstance(300,300, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(500,60,300,300);
        pan.add(lab);



        setUndecorated(true);
        setBounds(30,120,885, 500);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == add){
            String e_name = nameText.getText();
            String age = ageText.getText();
            String salary = salaryText.getText();
            String phone = phoneText.getText();
            String email = emailText.getText();
            String aadhar = aadharText.getText();
            String gender = (String) genderComboBox.getSelectedItem();;
            String job = (String) jobComboBox.getSelectedItem();


            try{
                con c = new con();
                String q = "insert into employee values('"+ e_name +"', '"+age+"', '"+gender+"', '"+job+"', '"+salary+"','"+phone+"', '"+email+"', '"+aadhar+"')";
                c.statement.executeUpdate(q);
                JOptionPane.showMessageDialog(null,"Employee Added");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();
            }
        }
        else{
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new AddEmployee();
    }
}
