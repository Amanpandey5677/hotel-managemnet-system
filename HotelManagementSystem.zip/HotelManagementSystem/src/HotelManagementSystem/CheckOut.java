package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;

public class CheckOut extends JFrame implements ActionListener {
    Choice ch;
    JTextField textField3, textField4, textField6;
    JButton check, back, checkOut;
    CheckOut(){
        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/checkout.png"));
        Image i = img.getImage().getScaledInstance(300,300,Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel label = new JLabel(imgg);
        label.setBounds(500,60,300,300);
        pan.add(label);

        JLabel label1  = new JLabel("Checkout");
        label1.setBounds(130,30,400,40);
        label1.setFont(new Font("serif", Font.BOLD, 35));
        label1.setForeground(new Color(13, 81,140));
        pan.add(label1);

        JLabel label2  = new JLabel("ID :");
        label2.setBounds(25,100,46,14);
        label2.setFont(new Font("serif", Font.BOLD, 14));
        label2.setForeground(new Color(13,81, 140));
        pan.add(label2);

        ch = new Choice();
        ch.setBounds(248,100,160,20);
        ch.setForeground(Color.WHITE);
        ch.setBackground(new Color(191, 135, 115));
        pan.add(ch);

        try {
            con c = new con();
            ResultSet rs = c.statement.executeQuery("select * from customerinfo");
            while (rs.next()){
                ch.add(rs.getString("d_number"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        JLabel label3  = new JLabel("Room Number :");
        label3.setBounds(25,160,107,30);
        label3.setFont(new Font("serif", Font.BOLD, 14));
        label3.setForeground(new Color(13,81, 140));
        pan.add(label3);

        textField3 = new JTextField();
        textField3.setBounds(248,160,160,20);
        textField3.setForeground(Color.WHITE);
        textField3.setBackground(new Color(191, 135, 115));
        pan.add(textField3);

        JLabel label4 = new JLabel("Check-In Time :");
        label4.setBounds(25,220,97,30);
        label4.setFont(new Font("serif", Font.BOLD, 14));
        label4.setForeground(new Color(13,81, 140));
        pan.add(label4);

        textField4 = new JTextField();
        textField4.setBounds(248,220,160,20);
        textField4.setForeground(Color.WHITE);
        textField4.setBackground(new Color(191, 135, 115));
        textField4.setEditable(false);
        pan.add(textField4);

        JLabel label5 = new JLabel("Check-Out Time");
        label5.setBounds(25,280,97,30);
        label5.setFont(new Font("serif", Font.BOLD, 14));
        label5.setForeground(new Color(13,81, 140));
        pan.add(label5);

        Date coDate = new Date();
        textField6 = new JTextField();
        textField6.setBounds(248,280,160,20);
        textField6.setForeground(Color.WHITE);
        textField6.setBackground(new Color(191, 135, 115));
        textField6.setText(""+coDate);
        pan.add(textField6);

        check = new JButton("Check");
        check.setBounds(40,430,100,30);
        check.setForeground(Color.BLACK);
        check.setBackground(new Color(191, 135, 115));
        check.addActionListener(this);
        pan.add(check);

        back = new JButton("Back");
        back.setBounds(190,430,100,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        checkOut = new JButton("Check-Out");
        checkOut.setBounds(340,430,100,30);
        checkOut.setForeground(Color.BLACK);
        checkOut.setBackground(new Color(191, 135, 115));
        checkOut.addActionListener(this);
        pan.add(checkOut);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()==check){
            String id = ch.getSelectedItem();
            String q = "select * from customerinfo where d_number ='"+id+"'";

            try{
                con c = new con();
                ResultSet rs = c.statement.executeQuery(q);

                while (rs.next()){
                    textField3.setText(rs.getString("room"));
                    textField4.setText(rs.getString("checkInTime"));
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else if (e.getSource() == checkOut) {

            try {
                con C  = new con();
                String d_num = ch.getSelectedItem();
                String r_num = textField3.getText();

                C.statement.executeUpdate("delete from customerinfo where d_number ='"+d_num+"'");
                C.statement.executeUpdate("update room  set availaibility = 'Available', cleaning_status = 'Dirty' where room_number = '"+ r_num +"'");
                JOptionPane.showMessageDialog(null, "Checked-Out Successfully");
                setVisible(false);

            }
            catch (Exception E){
                E.printStackTrace();
            }
        }
        else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new CheckOut();
    }
}
