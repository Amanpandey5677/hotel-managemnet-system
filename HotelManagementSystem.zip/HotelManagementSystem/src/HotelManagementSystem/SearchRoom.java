package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.DbUtils;

public class SearchRoom extends JFrame implements ActionListener {

    JCheckBox avail;
    Choice bed;
    JTable roomTable;
    JButton searchButton, backButton;
    SearchRoom(){
        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        JLabel labelName = new JLabel("Search For Room");
        labelName.setBounds(350,6,186,31);
        labelName.setFont(new Font("serif", Font.BOLD,20));
        labelName.setForeground(new Color(13,81, 140));
        pan.add(labelName);

        bed = new Choice();
        bed.add("Single Bed");
        bed.add("Double Bed");
        bed.setForeground(Color.WHITE);
        bed.setBackground(new Color(191, 135, 115));
        bed.setBounds(170,70,120,20);
        pan.add(bed);

        avail = new JCheckBox("Only Display Available");
        avail.setBounds(590,70,205,23);
        avail.setForeground(new Color(13,81, 140));
        avail.setBackground(new Color(242,242, 242));
        pan.add(avail);

        roomTable = new JTable();
        roomTable.setBounds(100,187,700,200);
        roomTable.setBackground(new Color(242, 242, 242));
        pan.add(roomTable);

        try{
            con c = new con();
            String q = "select * from room";
            ResultSet resultSet = c.statement.executeQuery(q);
            roomTable.setModel(DbUtils.resultSetToTableModel(resultSet));
        }
        catch (Exception e){
            e.printStackTrace();
        }


        JLabel rn = new JLabel("Room Number");
        rn.setBounds(120,162,150,20);
        rn.setFont(new Font("serif", Font.BOLD,14));
        rn.setForeground(new Color(13, 81, 140));
        pan.add(rn);

        JLabel available = new JLabel("Availability");
        available.setBounds(270,162,150,20);
        available.setFont(new Font("serif", Font.BOLD,14));
        available.setForeground(new Color(13, 81, 140));
        pan.add(available);

        JLabel CS = new JLabel("Clean Status");
        CS.setBounds(420,162,150,20);
        CS.setFont(new Font("serif", Font.BOLD,14));
        CS.setForeground(new Color(13, 81, 140));
        pan.add(CS);

        JLabel price = new JLabel("Price");
        price.setBounds(570,162,150,20);
        price.setFont(new Font("serif", Font.BOLD,14));
        price.setForeground(new Color(13, 81, 140));
        pan.add(price);

        JLabel BT = new JLabel("Bed Type");
        BT.setBounds(720,162,150,20);
        BT.setForeground(new Color(13, 81, 140));
        BT.setFont(new Font("serif", Font.BOLD,14));
        pan.add(BT);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/search.png"));
        Image i = img.getImage().getScaledInstance(305,204, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(600,300,350,380);
        pan.add(lab);


        searchButton = new JButton("Search");
        searchButton.setBounds(200,450,120,30);
        searchButton.setForeground(Color.BLACK);
        searchButton.setBackground(new Color(191, 135, 115));
        searchButton.addActionListener(this);
        pan.add(searchButton);

        backButton = new JButton("Back");
        backButton.setBounds(380,450,120,30);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(new Color(191, 135, 115));
        backButton.addActionListener(this);
        pan.add(backButton);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource()== searchButton){
            String q1 = "select * from room where bed_type = '"+bed.getSelectedItem()+"'";
            String q2 = "select * from room where availaibility = 'Available'  and bed_type = '"+bed.getSelectedItem()+"'";
            try {
                con c = new con();

                if (avail.isSelected()){
                    ResultSet resultSet1 = c.statement.executeQuery(q2);
                    roomTable.setModel(DbUtils.resultSetToTableModel(resultSet1));
                }
                else{
                    ResultSet resultSet = c.statement.executeQuery(q1);
                    roomTable.setModel(DbUtils.resultSetToTableModel(resultSet));
                }
            }catch (Exception E){
                E.printStackTrace();
            }

        }
        else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new SearchRoom();
    }
}
