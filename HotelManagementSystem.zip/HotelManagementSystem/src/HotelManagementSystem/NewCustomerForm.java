package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;

public class NewCustomerForm extends JFrame implements ActionListener {
    JComboBox idCB;
    JTextField numberTF , nameTF, countryTF, daysTF, depositTF;
    JRadioButton r1, r2;
    Choice ch;
    JLabel checkedInDate;
    JButton addButton, backButton;
    NewCustomerForm(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/customer.png"));
        Image i = img.getImage().getScaledInstance(400,225, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(480,180,400,225);
        pan.add(lab);

        JLabel labelName = new JLabel("New Customer Form");
        labelName.setBounds(140,0,260,60);
        labelName.setFont(new Font("serif", Font.BOLD,20));
        labelName.setForeground(new Color(13,81, 140));
        pan.add(labelName);

        JLabel ID = new JLabel("ID :");
        ID.setBounds(50,76,200,20);
        ID.setForeground(new Color(13,81, 140));
        ID.setFont(new Font("serif", Font.BOLD, 14));
        pan.add(ID);

        idCB = new JComboBox(new String[] {"Passport", "Aadhar Card", "Voter Id", "Driving License"});
        idCB.setBounds(271,73,200,20);
        idCB.setFont(new Font("serif", Font.PLAIN, 14));
        idCB.setForeground(Color.WHITE);
        idCB.setBackground(new Color(191, 135, 115));
        pan.add(idCB);

        JLabel number = new JLabel("Number :");
        number.setBounds(50,111,200,20);
        number.setFont(new Font("serif", Font.BOLD, 14));
        number.setForeground(new Color(13, 81, 140));
        pan.add(number);

        numberTF = new JTextField();
        numberTF.setBounds(271,111,200,20);
        numberTF.setFont(new Font("serif", Font.PLAIN, 14));
        numberTF.setForeground(Color.WHITE);
        numberTF.setBackground(new Color(191, 135, 115));
        pan.add(numberTF);

        JLabel name = new JLabel("Name :");
        name.setBounds(50,151,200,20);
        name.setForeground(new Color(13, 81, 140));
        name.setFont(new Font("serif", Font.BOLD, 14));
        pan.add(name);

        nameTF = new JTextField();
        nameTF.setBounds(271,151,200,20);
        nameTF.setFont(new Font("serif", Font.PLAIN, 14));
        nameTF.setForeground(Color.WHITE);
        nameTF.setBackground(new Color(191, 135, 115));
        pan.add(nameTF);

        JLabel gender = new JLabel("Gender :");
        gender.setBounds(50,191,200,20);
        gender.setForeground(new Color(13, 81, 140));
        gender.setFont(new Font("serif", Font.BOLD, 14));
        pan.add(gender);

        r1 = new JRadioButton("Male");
        r1.setBounds(271,191,90,12);
        r1.setFont(new Font("serif", Font.PLAIN, 14));
        r1.setForeground(new Color(13, 81, 140));
        r1.setBackground(new Color(242, 242, 242));
        pan.add(r1);

        r2 = new JRadioButton("Female");
        r2.setBounds(371,191,90,12);
        r2.setFont(new Font("serif", Font.PLAIN, 14));
        r2.setForeground(new Color(13, 81, 140));
        r2.setBackground(new Color(242, 242, 242));
        pan.add(r2);

        JLabel Country = new JLabel("Country :");
        Country.setBounds(50,231,200,20);
        Country.setFont(new Font("serif", Font.BOLD, 14));
        Country.setForeground(new Color(13,81, 140));
        pan.add(Country);

        countryTF = new JTextField();
        countryTF.setBounds(271,231,200,20);
        countryTF.setFont(new Font("serif", Font.PLAIN, 14));
        countryTF.setForeground(Color.WHITE);
        countryTF.setBackground(new Color(191, 135, 115));
        pan.add(countryTF);

        JLabel Room = new JLabel("Allocated Room Number :");
        Room.setBounds(50,274,200,20);
        Room.setFont(new Font("serif", Font.BOLD, 14));
        Room.setForeground(new Color(13, 81, 140));
        pan.add(Room);

        ch = new Choice();
        ch.setBounds(271,274,200,20);
        ch.setFont(new Font("serif", Font.PLAIN, 14));
        ch.setForeground(Color.WHITE);
        ch.setBackground(new Color(191, 135, 115));
        pan.add(ch);

        try{
            con c = new con();
            ResultSet rs = c.statement.executeQuery("select * from room");
            while (rs.next()){
                ch.add(rs.getString("room_number"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        JLabel checked_in = new JLabel("Checked-In :");
        checked_in.setBounds(50,316,200,20);
        checked_in.setForeground(new Color(13, 81, 140));
        checked_in.setFont(new Font("serif", Font.BOLD, 14));
        pan.add(checked_in);

        Date date1 = new Date();
        checkedInDate = new JLabel(""+date1);
        checkedInDate.setBounds(271,316,200,20);
        checkedInDate.setFont(new Font("serif", Font.PLAIN, 14));
        checkedInDate.setForeground(new Color(13, 81, 140));
        pan.add(checkedInDate);

        JLabel days = new JLabel("Number of Days :");
        days.setBounds(50,359,200,20);
        days.setFont(new Font("serif", Font.BOLD, 14));
        days.setForeground(new Color(13, 81, 140));
        pan.add(days);

        daysTF = new JTextField();
        daysTF.setBounds(271,359,200,20);
        daysTF.setFont(new Font("serif", Font.PLAIN, 14));
        daysTF.setForeground(Color.WHITE);
        daysTF.setBackground(new Color(191, 135, 115));
        pan.add(daysTF);

        JLabel Deposit = new JLabel("Deposit :");
        Deposit.setBounds(50,402,200,20);
        Deposit.setFont(new Font("serif", Font.BOLD, 14));
        Deposit.setForeground(new Color(13, 81, 140));
        pan.add(Deposit);

        depositTF = new JTextField();
        depositTF.setBounds(271,402,200,20);
        depositTF.setFont(new Font("serif", Font.PLAIN, 14));
        depositTF.setForeground(Color.WHITE);
        depositTF.setBackground(new Color(191, 135, 115));
        pan.add(depositTF);

        addButton = new JButton("ADD");
        addButton.setBounds(100,480,120,30);
        addButton.setForeground(Color.BLACK);
        addButton.setBackground(new Color(191, 135, 115));
        addButton.addActionListener(this);
        pan.add(addButton);

        backButton = new JButton("BACK");
        backButton.setBounds(260,480,120,30);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(new Color(191, 135, 115));
        backButton.addActionListener(this);
        pan.add(backButton);


        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == addButton){

            con c = new con();

            String radioBTn = null;
            if (r1.isSelected()){
                radioBTn = "Male";
            }
            else if (r2.isSelected()) {
                radioBTn = "Female";
            }
            String s1 = (String)idCB.getSelectedItem();
            String s2 =  numberTF.getText();
            String s3 =  nameTF.getText();
            String s4 =  radioBTn;
            String s5 =  countryTF.getText();
            String s6 =  ch.getSelectedItem();
            String s7 =  checkedInDate.getText();
            String s8 =  daysTF.getText();
            String s9 =  depositTF.getText();

            try {

                String q1 ="insert into customerinfo values ('"+s1+"', '"+s2+"','"+s3+"','"+s4+"', '"+s5+"', '"+s6+"', '"+s7+"', '"+s8+"', '"+s9+"')";
                String q2 = "update room set availaibility = 'Occupied' where room_number = "+s6;
                c.statement.executeUpdate(q1);
                c.statement.executeUpdate(q2);
                JOptionPane.showMessageDialog(null, "added Successfully");
                setVisible(false);

            }catch (Exception E) {
                E.printStackTrace();
            }
        }
        else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new NewCustomerForm();
    }
}
