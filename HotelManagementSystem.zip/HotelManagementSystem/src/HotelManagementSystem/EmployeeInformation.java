package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.DbUtils;

public class EmployeeInformation extends JFrame implements ActionListener {

    JButton back;
    EmployeeInformation(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        JTable empInfoTable = new JTable();
        empInfoTable.setBounds(10, 40, 865, 400);
        empInfoTable.setBackground(new Color(242, 242, 242));
        pan.add(empInfoTable);

        try{
            con c = new con();
            String q = "select * from employee";
            ResultSet rs = c.statement.executeQuery(q);
            empInfoTable.setModel(DbUtils.resultSetToTableModel(rs));

        }catch (Exception e){
            e.printStackTrace();
        }

        back = new JButton("BACK");
        back.setBounds(200,500,120,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        JLabel name = new JLabel("Name");
        name.setBounds(40,11,70,19);
        name.setFont(new Font("serif", Font.BOLD,14));
        name.setForeground(new Color(13, 81, 140));
        pan.add(name);

        JLabel Age = new JLabel("Age");
        Age.setBounds(150,11,70,19);
        Age.setFont(new Font("serif", Font.BOLD,14));
        Age.setForeground(new Color(13, 81, 140));
        pan.add(Age);

        JLabel gender = new JLabel("Gender");
        gender.setBounds(260,11,70,19);
        gender.setFont(new Font("serif", Font.BOLD,14));
        gender.setForeground(new Color(13, 81, 140));
        pan.add(gender);

        JLabel job = new JLabel("Job");
        job.setBounds(370,11,70,19);
        job.setFont(new Font("serif", Font.BOLD,14));
        job.setForeground(new Color(13, 81, 140));
        pan.add(job);

        JLabel salary = new JLabel("Salary");
        salary.setBounds(480,11,70,19);
        salary.setFont(new Font("serif", Font.BOLD,14));
        salary.setForeground(new Color(13, 81, 140));
        pan.add(salary);

        JLabel phone = new JLabel("Phone");
        phone.setBounds(590,11,70,19);
        phone.setFont(new Font("serif", Font.BOLD,14));
        phone.setForeground(new Color(13, 81, 140));
        pan.add(phone);

        JLabel mail = new JLabel("Mail");
        mail.setBounds(700,11,70,19);
        mail.setFont(new Font("serif", Font.BOLD,14));
        mail.setForeground(new Color(13,81,140));
        pan.add(mail);

        JLabel aadhar = new JLabel("Aadhar");
        aadhar.setBounds(810,11,70,19);
        aadhar.setFont(new Font("serif", Font.BOLD,14));
        aadhar.setForeground(new Color(13, 81, 140));
        pan.add(aadhar);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        setVisible(false);
    }

    public static void main(String[] args) {
        new EmployeeInformation();
    }
}
