package HotelManagementSystem;
import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class CustomerInformation extends JFrame implements ActionListener {

    JButton back;

    CustomerInformation(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        JTable customerInfoTable = new JTable();
        customerInfoTable.setBounds(10, 50, 865, 400);
        customerInfoTable.setBackground(new Color(242, 242, 242));
        pan.add(customerInfoTable);

        try{
            con c = new con();
            String q = "select * from customerinfo";
            ResultSet rs = c.statement.executeQuery(q);
            customerInfoTable.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch (Exception e){
            e.printStackTrace();
        }

        JLabel id = new JLabel("ID");
        id.setBounds(30,10,100,16);
        id.setFont( new Font("serif", Font.BOLD,14));
        id.setForeground(new Color(13, 81, 140));
        pan.add(id);

        JLabel number = new JLabel("Number");
        number.setBounds(120,10,100,16);
        number.setFont( new Font("serif", Font.BOLD,14));
        number.setForeground(new Color(13, 81, 140));
        pan.add(number);

        JLabel name = new JLabel("Name");
        name.setBounds(210,10,100,16);
        name.setFont( new Font("serif", Font.BOLD,14));
        name.setForeground(new Color(13, 81, 140));
        pan.add(name);

        JLabel gender = new JLabel("Gender");
        gender.setBounds(310,10,100,16);
        gender.setFont( new Font("serif", Font.BOLD,14));
        gender.setForeground(new Color(13, 81, 140));
        pan.add(gender);

        JLabel country = new JLabel("Country");
        country.setBounds(420,10,100,16);
        country.setFont( new Font("serif", Font.BOLD,14));
        country.setForeground(new Color(13, 81, 140));
        pan.add(country);

        JLabel room = new JLabel("Room");
        room.setBounds(510,10,100,16);
        room.setFont( new Font("serif", Font.BOLD,14));
        room.setForeground(new Color(13, 81, 140));
        pan.add(room);

        JLabel Time = new JLabel("CI Time");
        Time.setBounds(600,10,100,16);
        Time.setFont( new Font("serif", Font.BOLD,14));
        Time.setForeground(new Color(13, 81, 140));
        pan.add(Time);

        JLabel NoOfDays = new JLabel("No. of Days");
        NoOfDays.setBounds(690,10,100,16);
        NoOfDays.setFont( new Font("serif", Font.BOLD,14));
        NoOfDays.setForeground(new Color(13, 81, 140));
        pan.add(NoOfDays);

        JLabel Deposit = new JLabel("Deposit");
        Deposit.setBounds(790,10,100,16);
        Deposit.setFont( new Font("serif", Font.BOLD,14));
        Deposit.setForeground(new Color(13, 81, 140));
        pan.add(Deposit);

        back = new JButton("BACK");
        back.setBounds(200,500,120,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        setVisible(false);
    }

    public static void main(String[] args) {
        new CustomerInformation();
    }
}
