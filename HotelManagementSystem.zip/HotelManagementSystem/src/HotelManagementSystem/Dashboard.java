package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame implements ActionListener {
    JButton adminButton, receptionButton;
    Dashboard(){

        super("Dashboard");

        adminButton = new JButton("Admin");
        adminButton.setBounds(425,510,140,30);
        adminButton.setFont(new Font("Calibri", Font.BOLD,18));
        adminButton.setForeground(Color.WHITE);
        adminButton.setBackground(new Color(255,98,0));
        adminButton.addActionListener(this);
        add(adminButton);

        receptionButton = new JButton("Reception");
        receptionButton.setBounds(880,510,140,30);
        receptionButton.setFont(new Font("Calibri", Font.BOLD,18));
        receptionButton.setForeground(Color.WHITE);
        receptionButton.setBackground(new Color(255,98,0));
        receptionButton.addActionListener(this);
        add(receptionButton);

        ImageIcon img2 = new ImageIcon(ClassLoader.getSystemResource("icons/adminbutton.png"));
        Image i2 = img2.getImage().getScaledInstance(200,195, Image.SCALE_DEFAULT);
        ImageIcon imgg2 = new ImageIcon(i2);
        JLabel l2 = new JLabel(imgg2);
        l2.setBounds(850,300,200,195);
        add(l2);

        ImageIcon img3 = new ImageIcon(ClassLoader.getSystemResource("icons/receptionButton.png"));
        Image i3 = img3.getImage().getScaledInstance(200,195, Image.SCALE_DEFAULT);
        ImageIcon imgg3 = new ImageIcon(i3);
        JLabel l3 = new JLabel(imgg3);
        l3.setBounds(400,300,200,195);
        add(l3);


        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/dashboard.jpg"));
        Image i1 = img.getImage().getScaledInstance(1950, 820, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i1);
        JLabel l1 = new JLabel(imgg);
        l1.setBounds(0, 0, 1950, 820);
        add(l1);

        setLayout(null);
        setSize(1950, 820);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == receptionButton){
            new Reception();
            setVisible(false);
        }
        else{
            new AdminLogin();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Dashboard();
    }
}
