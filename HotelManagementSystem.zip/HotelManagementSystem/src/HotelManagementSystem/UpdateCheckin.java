package HotelManagementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class UpdateCheckin extends JFrame implements ActionListener {
    Choice ch;
    JTextField textField3, textField4, textField5, textField6, textField7, textField8;
    JButton check, update, back;


    UpdateCheckin(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/update.png"));
        Image i = img.getImage().getScaledInstance(300,300,Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel label = new JLabel(imgg);
        label.setBounds(500,60,300,300);
        pan.add(label);

        JLabel label1  = new JLabel("Update Check-In Details");
        label1.setBounds(124,11,222,25);
        label1.setFont(new Font("serif", Font.BOLD, 20));
        label1.setForeground(new Color(13, 81,140));
        pan.add(label1);

        JLabel label2  = new JLabel("ID :");
        label2.setBounds(25,88,46,14);
        label2.setFont(new Font("serif", Font.BOLD, 14));
        label2.setForeground(new Color(13,81, 140));
        pan.add(label2);

        ch = new Choice();
        ch.setBounds(248,85,140,20);
        ch.setForeground(Color.WHITE);
        ch.setBackground(new Color(191, 135, 115));
        pan.add(ch);

        try {
            con c = new con();
            ResultSet rs = c.statement.executeQuery("select * from customerinfo");
            while (rs.next()){
                ch.add(rs.getString("d_number"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        JLabel label3  = new JLabel("Room Number :");
        label3.setBounds(25,129,107,30);
        label3.setFont(new Font("serif", Font.BOLD, 14));
        label3.setForeground(new Color(13,81, 140));
        pan.add(label3);

        textField3 = new JTextField();
        textField3.setBounds(248,129,140,20);
        textField3.setForeground(Color.WHITE);
        textField3.setBackground(new Color(191, 135, 115));
        pan.add(textField3);

        JLabel label4  = new JLabel("Name :");
        label4.setBounds(25,174,97,30);
        label4.setFont(new Font("serif", Font.BOLD, 14));
        label4.setForeground(new Color(13,81, 140));
        pan.add(label4);

        textField4 = new JTextField();
        textField4.setBounds(248,174,140,20);
        textField4.setForeground(Color.WHITE);
        textField4.setBackground(new Color(191, 135, 115));
        pan.add(textField4);

        JLabel label5  = new JLabel("Checked-in :");
        label5.setBounds(25,216,97,30);
        label5.setFont(new Font("serif", Font.BOLD, 14));
        label5.setForeground(new Color(13,81, 140));
        pan.add(label5);

        textField5 = new JTextField();
        textField5.setBounds(248,216,140,20);
        textField5.setForeground(Color.WHITE);
        textField5.setBackground(new Color(191, 135, 115));
        textField5.setEditable(false);
        pan.add(textField5);

        JLabel label6 = new JLabel("No of Days");
        label6.setBounds(25,261,97,30);
        label6.setFont(new Font("serif", Font.BOLD, 14));
        label6.setForeground(new Color(13,81, 140));
        pan.add(label6);

        textField6 = new JTextField();
        textField6.setBounds(248,261,140,20);
        textField6.setForeground(Color.WHITE);
        textField6.setBackground(new Color(191, 135, 115));
        textField6.setEditable(false);
        pan.add(textField6);

        JLabel label7 = new JLabel("Amount Paid (Rs) :");
        label7.setBounds(25,302,150,30);
        label7.setFont(new Font("serif", Font.BOLD, 14));
        label7.setForeground(new Color(13,81, 140));
        pan.add(label7);

        textField7 = new JTextField();
        textField7.setBounds(248,302,140,20);
        textField7.setForeground(Color.WHITE);
        textField7.setBackground(new Color(191, 135, 115));
        pan.add(textField7);

        JLabel label8 = new JLabel("Pending Amount (Rs) :");
        label8.setBounds(25,345,150,30);
        label8.setFont(new Font("serif", Font.BOLD, 14));
        label8.setForeground(new Color(13,81, 140));
        pan.add(label8);

        textField8 = new JTextField();
        textField8.setBounds(248,345,140,20);
        textField8.setForeground(Color.WHITE);
        textField8.setBackground(new Color(191, 135, 115));
        pan.add(textField8);

        check = new JButton("Check");
        check.setBounds(56,400,89,23);
        check.setForeground(Color.BLACK);
        check.setBackground(new Color(191, 135, 115));
        check.addActionListener(this);
        pan.add(check);

        update = new JButton("Update");
        update.setBounds(168,400,89,23);
        update.setForeground(Color.BLACK);
        update.setBackground(new Color(191, 135, 115));
        update.addActionListener(this);
        pan.add(update);

        back = new JButton("Back");
        back.setBounds(281,400,89,23);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource()==check){
            String id = ch.getSelectedItem();
            String q = "select * from customerinfo where d_number ='"+id+"'";

            try{
               con c = new con();
               ResultSet rs = c.statement.executeQuery(q);

               while (rs.next()){
                   textField3.setText(rs.getString("room"));
                   textField4.setText(rs.getString("c_name"));
                   textField5.setText(rs.getString("checkInTime"));
                   textField6.setText(rs.getString("no_of_days"));
                   textField7.setText(rs.getString("deposit"));
               }
               //  (nod * room price) - deposit
               ResultSet rs2 = c.statement.executeQuery("select price from room where room_number ='"+textField3.getText()+"'");
               while (rs2.next()){
                   String price = rs2.getString("price");
                   int amountToBePaid = ( Integer.parseInt(textField6.getText()) * Integer.parseInt(price)  ) - Integer.parseInt(textField7.getText());
                   textField8.setText(""+amountToBePaid);
               }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }

        }
        else if (e.getSource()==update) {
            try {
                con C  = new con();
                String d_id = ch.getSelectedItem();
                String r_no = textField3.getText();
                String name = textField4.getText();
                String amount = textField7.getText();

                C.statement.executeUpdate("update customerinfo  set room = '"+ r_no +"', c_name = '"+name+"', deposit = '"+amount+"' where d_number = '"+d_id+"'");
                JOptionPane.showMessageDialog(null, "Updated Successfully");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();
            }
        }
        else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new UpdateCheckin();
    }
}
