package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Admin extends JFrame implements ActionListener {

    JButton add_Employee, add_Room, add_Driver, logout, back;
    Admin(){
        super("Admin");

        add_Employee = new JButton( "ADD EMPLOYEE");
        add_Employee.setBounds(250,200,200,30);
        add_Employee.setBackground(new Color(13, 81, 140));
        add_Employee.setForeground(Color.WHITE);
        add_Employee.setFont(new Font("Tahoma", Font.BOLD, 15));
        add_Employee.addActionListener(this);
        add(add_Employee);

        add_Room = new JButton( "ADD ROOM");
        add_Room.setBounds(250,350,200,30);
        add_Room.setBackground(new Color(13, 81, 140));
        add_Room.setForeground(Color.WHITE);
        add_Room.setFont(new Font("Tahoma", Font.BOLD, 15));
        add_Room.addActionListener(this);
        add(add_Room);

        add_Driver = new JButton( "ADD DRIVER");
        add_Driver.setBounds(250,500,200,30);
        add_Driver.setBackground(new Color(13, 81, 140));
        add_Driver.setForeground(Color.WHITE);
        add_Driver.setFont(new Font("Tahoma", Font.BOLD, 15));
        add_Driver.addActionListener(this);
        add(add_Driver);

        logout = new JButton( "Logout");
        logout.setBounds(30,730,100,30);
        logout.setBackground(new Color(191, 135, 115));
        logout.setForeground(Color.WHITE);
        logout.setFont(new Font("Tahoma", Font.BOLD, 15));
        logout.addActionListener(this);
        add(logout);

        back = new JButton( "Back");
        back.setBounds(150,730,100,30);
        back.setBackground(new Color(191, 135, 115));
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Tahoma", Font.BOLD, 15));
        back.addActionListener(this);
        add(back);

        ImageIcon img1 = new ImageIcon(ClassLoader.getSystemResource("icons/add_Employee.png"));
        Image i1 = img1.getImage().getScaledInstance(120,120, Image.SCALE_DEFAULT);
        ImageIcon imgg1 = new ImageIcon(i1);
        JLabel l1 = new JLabel(imgg1);
        l1.setBounds(70,150,120,120);
        add(l1);

        ImageIcon img2 = new ImageIcon(ClassLoader.getSystemResource("icons/add_Room.png"));
        Image i2 = img2.getImage().getScaledInstance(120,120, Image.SCALE_DEFAULT);
        ImageIcon imgg2 = new ImageIcon(i2);
        JLabel l2 = new JLabel(imgg2);
        l2.setBounds(70,300,120,120);
        add(l2);

        ImageIcon img3 = new ImageIcon(ClassLoader.getSystemResource("icons/add_Driver.png"));
        Image i3 = img3.getImage().getScaledInstance(120,120, Image.SCALE_DEFAULT);
        ImageIcon imgg3 = new ImageIcon(i3);
        JLabel l3 = new JLabel(imgg3);
        l3.setBounds(70,450,120,120);
        add(l3);

        ImageIcon img4 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i4 = img4.getImage().getScaledInstance(400,400, Image.SCALE_DEFAULT);
        ImageIcon imgg4 = new ImageIcon(i4);
        JLabel l4 = new JLabel(imgg4);
        l4.setBounds(1000,150,400,400);
        add(l4);


        getContentPane().setBackground(new Color(242, 242, 242));  // To change color of frame
        setLayout(null);
        setSize(1950, 820);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if (e.getSource() == add_Employee){
            new AddEmployee();
        }
        else if (e.getSource() == add_Room) {
            new Add_Room();
        }
        else if (e.getSource() ==  add_Driver) {
            new AddDriver();
        }
        else if (e.getSource() == logout){
            System.exit(102);
        }
        else  {
            new Dashboard();
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Admin();
    }
}
