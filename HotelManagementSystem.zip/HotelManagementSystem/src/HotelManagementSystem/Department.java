package HotelManagementSystem;
import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Department extends JFrame implements ActionListener {

    JTable departmentTable;
    JButton back;

    Department(){

        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/departmentBudget.png"));
        Image i = img.getImage().getScaledInstance(180,180, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(650,326,180,180);
        pan.add(lab);

        departmentTable = new JTable();
        departmentTable.setBounds(10, 40, 500, 400);
        departmentTable.setBackground(new Color(242, 242, 242));
        pan.add(departmentTable);

        try{
            con c =new con();
            String q = "select * from department";
            ResultSet rs = c.statement.executeQuery(q);
            departmentTable.setModel(DbUtils.resultSetToTableModel(rs));

        }catch (Exception e){
            e.printStackTrace();
        }

        back = new JButton("BACK");
        back.setBounds(200,500,120,30);
        back.setForeground(Color.BLACK);
        back.setBackground(new Color(191, 135, 115));
        back.addActionListener(this);
        pan.add(back);

        JLabel label1 = new JLabel("Department");
        label1.setBounds(120,11,105,20);
        label1.setForeground(new Color(13, 81, 140));
        label1.setFont(new Font("Tahoma", Font.BOLD,14));
        pan.add(label1);

        JLabel label2 = new JLabel("Budget");
        label2.setBounds(350,11,105,20);
        label2.setForeground(new Color(13, 81, 140));
        label2.setFont(new Font("Tahoma", Font.BOLD,14));
        pan.add(label2);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource()== back){
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Department();
    }
}
