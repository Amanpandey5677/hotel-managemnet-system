package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {

    JTextField tf1;
    JPasswordField pf1;
    JButton b1, b2;
    Login(){

        JLabel l1 = new JLabel("Login");
        l1.setBounds(240, 15, 100, 30);
        l1.setFont(new Font("Bauhaus 93", Font.PLAIN, 30));
        add(l1);

        JLabel l2 = new JLabel("Username: ");
        l2.setBounds(40, 80, 100, 30);
        l2.setFont(new Font("Tahoma", Font.BOLD, 16));
        add(l2);

        JLabel l3 = new JLabel("Password: ");
        l3.setBounds(40, 130, 100, 30);
        l3.setFont(new Font("Tahoma", Font.BOLD, 16));
        add(l3);

        tf1 = new JTextField();
        tf1.setBounds(150, 80, 150, 30);
        tf1.setFont(new Font("Calibri", Font.BOLD, 16));
        add(tf1);

        pf1 = new JPasswordField();
        pf1.setBounds(150, 130, 150, 30);
        pf1.setFont(new Font("Calibri", Font.BOLD, 16));
        add(pf1);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i1 = img.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);  // To scale image
        JLabel l4 = new JLabel(img);
        l4.setBounds(330, 20, 200, 200);
        add(l4);

        b1 = new JButton("Login");
        b1.setBounds(40,200,120,30);
        b1.setFont(new Font("serif", Font.BOLD, 15));
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("Cancel");
        b2.setBounds(180,200,120,30);
        b2.setFont(new Font("serif", Font.BOLD, 15));
        b2.addActionListener(this);
        add(b2);


        getContentPane().setBackground(Color.WHITE);  // To change color of frame
        setLayout(null);
        setBounds(500, 200, 600, 300);
        setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource()== b1){
            try{
                con c = new con();
                String user = tf1.getText();
                String pass = String.valueOf(pf1.getPassword());

                String q = "select * from login where username = '"+user+"' and u_password = '"+pass+"' ";
                ResultSet rs = c.statement.executeQuery(q);
                if (rs.next()){
                    setVisible(false);
                    new Dashboard();
                }else{
                    JOptionPane.showMessageDialog(null,"Invalid username or password");
                }
            }catch (Exception E){
                E.printStackTrace();
            }
        }
        else {
            System.exit(102);  // we can giv any int value. On clicking b2, 102 will be displayed after closing of app
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}
