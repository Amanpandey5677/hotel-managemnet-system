package HotelManagementSystem;
import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class PickUpService extends JFrame implements ActionListener {

    Choice loc, carType;
    JTable carTable;
    JButton searchButton, backButton;
    PickUpService(){
        JPanel pan = new JPanel();
        pan.setBounds(5,5,890, 590);
        pan.setBackground(new Color(242, 242, 242));
        pan.setLayout(null);
        add(pan);

        JLabel labelName = new JLabel("Pick Up Service");
        labelName.setBounds(350,6,186,31);
        labelName.setFont(new Font("serif", Font.BOLD,20));
        labelName.setForeground(new Color(13,81, 140));
        pan.add(labelName);

        loc = new Choice();
        loc.add("Airport");
        loc.add("Railway Station");
        loc.setForeground(Color.WHITE);
        loc.setBackground(new Color(191, 135, 115));
        loc.setBounds(170,70,120,20);
        pan.add(loc);

        carType = new Choice();
        carType.add("Any");
        carType.add("Seltos");
        carType.add("Swift");
        carType.add("Innova");
        carType.add("Amaze");
        carType.setForeground(Color.WHITE);
        carType.setBackground(new Color(191, 135, 115));
        carType.setBounds(590,70,120,20);
        pan.add(carType);

        carTable = new JTable();
        carTable.setBounds(50,187,800,200);
        carTable.setBackground(new Color(242, 242, 242));
        pan.add(carTable);

        try{
            con c = new con();
            String q = "select * from driver";
            ResultSet resultSet = c.statement.executeQuery(q);
            carTable.setModel(DbUtils.resultSetToTableModel(resultSet));
        }
        catch (Exception e){
            e.printStackTrace();
        }

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/taxi.png"));
        Image i = img.getImage().getScaledInstance(305,204, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(600,350,270,250);
        pan.add(lab);

        searchButton = new JButton("Search");
        searchButton.setBounds(200,450,120,30);
        searchButton.setForeground(Color.BLACK);
        searchButton.setBackground(new Color(191, 135, 115));
        searchButton.addActionListener(this);
        pan.add(searchButton);

        backButton = new JButton("Back");
        backButton.setBounds(380,450,120,30);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(new Color(191, 135, 115));
        backButton.addActionListener(this);
        pan.add(backButton);

        JLabel name = new JLabel("Name");
        name.setBounds(75,162,46,14);
        name.setForeground(new Color(13, 81, 140));
        pan.add(name);

        JLabel age = new JLabel("Age");
        age.setBounds(220,162,46,14);
        age.setForeground(new Color(13, 81, 140));
        pan.add(age);

        JLabel gender = new JLabel("Gender");
        gender.setBounds(310,162,46,14);
        gender.setForeground(new Color(13, 81, 140));
        pan.add(gender);

        JLabel company = new JLabel("Company");
        company.setBounds(420,162,100,14);
        company.setForeground(new Color(13, 81, 140));
        pan.add(company);

        JLabel carName = new JLabel("Car Name");
        carName.setBounds(540,162,100,14);
        carName.setForeground(new Color(13, 81, 140));
        pan.add(carName);

        JLabel available = new JLabel("Available");
        available.setBounds(650,162,100,14);
        available.setForeground(new Color(13, 81, 140));
        pan.add(available);

        JLabel location = new JLabel("Location");
        location.setBounds(750,162,100,14);
        location.setForeground(new Color(13, 81, 140));
        pan.add(location);

        setUndecorated(true);
        setLayout(null);
        setBounds(500,100,900,600);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == searchButton){
            String q1 = "select * from driver where location = '"+loc.getSelectedItem()+"'";
            String q2 = "select * from driver where location = '"+loc.getSelectedItem()+"' and c_name = '"+carType.getSelectedItem()+"'";

            try {
                con c = new con();

                if (carType.getSelectedItem().equals("Any")){
                    ResultSet rs1 = c.statement.executeQuery(q1);
                    carTable.setModel(DbUtils.resultSetToTableModel(rs1));
                }
                else{
                    ResultSet rs2 = c.statement.executeQuery(q2);
                    carTable.setModel(DbUtils.resultSetToTableModel(rs2));
                }
            }catch (Exception E){
                E.printStackTrace();
            }
        }
        else {
            setVisible(false);
        }

    }

    public static void main(String[] args) {
        new PickUpService();
    }
}
