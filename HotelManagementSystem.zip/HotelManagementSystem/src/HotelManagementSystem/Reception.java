package HotelManagementSystem;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reception extends JFrame implements ActionListener {

    JButton btn_NCF, btn_room, btn_department, btn_AEI, btn_CI, btn_MI, btn_CO, btn_CID, btn_URS, btn_PUS, btn_SR, btn_logout, btn_back;
    Reception(){
        super("Reception");

        JPanel pan1 = new JPanel();
        pan1.setLayout(null);
        pan1.setBounds(280, 5, 1240, 770);
        pan1.setBackground(new Color(236, 240, 239));
        add(pan1);

        JPanel pan2 = new JPanel();
        pan2.setLayout(null);
        pan2.setBounds(5, 5, 270, 770);
        pan2.setBackground(new Color(236, 240, 239));
        add(pan2);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icons/reception.jpg"));
        Image i = img.getImage().getScaledInstance(626,377, Image.SCALE_DEFAULT);
        ImageIcon imgg = new ImageIcon(i);
        JLabel lab = new JLabel(imgg);
        lab.setBounds(320,170,626,377);
        pan1.add(lab);

        btn_NCF = new JButton("New Customer Form");
        btn_NCF.setBounds(30,50,200,30);
        btn_NCF.setBackground(new Color(13, 81, 140));
        btn_NCF.setForeground(Color.WHITE);
        btn_NCF.addActionListener(this);
        pan2.add(btn_NCF);

        btn_room = new JButton("Room");
        btn_room.setBounds(30,100,200,30);
        btn_room.setBackground(new Color(13, 81, 140));
        btn_room.setForeground(Color.WHITE);
        btn_room.addActionListener(this);
        pan2.add(btn_room);

        btn_department = new JButton("Department");
        btn_department.setBounds(30,150,200,30);
        btn_department.setBackground(new Color(13, 81, 140));
        btn_department.setForeground(Color.WHITE);
        btn_department.addActionListener(this);
        pan2.add(btn_department);

        btn_AEI = new JButton("Employee Info");
        btn_AEI.setBounds(30,200,200,30);
        btn_AEI.setBackground(new Color(13, 81, 140));
        btn_AEI.setForeground(Color.WHITE);
        btn_AEI.addActionListener(this);
        pan2.add(btn_AEI);

        btn_CI = new JButton("Customer Info");
        btn_CI.setBounds(30,250,200,30);
        btn_CI.setBackground(new Color(13, 81, 140));
        btn_CI.setForeground(Color.WHITE);
        btn_CI.addActionListener(this);
        pan2.add(btn_CI);

        btn_MI = new JButton("Manager Info");
        btn_MI.setBounds(30,300,200,30);
        btn_MI.setBackground(new Color(13, 81, 140));
        btn_MI.setForeground(Color.WHITE);
        btn_MI.addActionListener(this);
        pan2.add(btn_MI);

        btn_CO = new JButton("Check Out");
        btn_CO.setBounds(30,350,200,30);
        btn_CO.setBackground(new Color(13, 81, 140));
        btn_CO.setForeground(Color.WHITE);
        btn_CO.addActionListener(this);
        pan2.add(btn_CO);

        btn_CID = new JButton("Check-In Details");
        btn_CID.setBounds(30,400,200,30);
        btn_CID.setBackground(new Color(13, 81, 140));
        btn_CID.setForeground(Color.WHITE);
        btn_CID.addActionListener(this);
        pan2.add(btn_CID);

        btn_URS = new JButton("Update Room Status");
        btn_URS.setBounds(30,450,200,30);
        btn_URS.setBackground(new Color(13, 81, 140));
        btn_URS.setForeground(Color.WHITE);
        btn_URS.addActionListener(this);
        pan2.add(btn_URS);

        btn_PUS = new JButton("Pick Up Service");
        btn_PUS.setBounds(30,500,200,30);
        btn_PUS.setBackground(new Color(13, 81, 140));
        btn_PUS.setForeground(Color.WHITE);
        btn_PUS.addActionListener(this);
        pan2.add(btn_PUS);

        btn_SR = new JButton("Search Room");
        btn_SR.setBounds(30,550,200,30);
        btn_SR.setBackground(new Color(13, 81, 140));
        btn_SR.setForeground(Color.WHITE);
        btn_SR.addActionListener(this);
        pan2.add(btn_SR);

        btn_logout = new JButton("Logout");
        btn_logout.setBounds(30,600,200,30);
        btn_logout.setBackground(new Color(191, 135, 115));
        btn_logout.setForeground(Color.WHITE);
        btn_logout.addActionListener(this);
        pan2.add(btn_logout);

        btn_back = new JButton("Back");
        btn_back.setBounds(30,650,200,30);
        btn_back.setBackground(new Color(191, 135, 115));
        btn_back.setForeground(Color.WHITE);
        btn_back.addActionListener(this);
        pan2.add(btn_back);

        getContentPane().setBackground(Color.WHITE);  // To change color of frame
        setLayout(null);
        setSize(1950, 820);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == btn_NCF){
            new NewCustomerForm();
        }
        else if (e.getSource() == btn_room) {
            new Room();
        }
        else if (e.getSource() == btn_department) {
            new Department();
        }
        else if (e.getSource() == btn_AEI) {
            new EmployeeInformation();
        }
        else if (e.getSource() == btn_CI) {
            new CustomerInformation();
        }
        else if (e.getSource() == btn_MI) {
            new ManagerInformation();
        }
        else if (e.getSource() == btn_CO) {
            new CheckOut();
        }
        else if (e.getSource() == btn_CID) {
            new UpdateCheckin();
        }
        else if (e.getSource() == btn_URS) {
            new UpdateRoomStatus();
        }
        else if (e.getSource() == btn_PUS) {
            new PickUpService();

        }
        else if (e.getSource() == btn_SR) {
            new SearchRoom();

        }
        else if (e.getSource() == btn_logout){
            System.exit(102);
        }
        else  {
            new Dashboard();
            setVisible(false);
        }
    }

    public static void main(String[] args){
        new Reception();
    }
}
